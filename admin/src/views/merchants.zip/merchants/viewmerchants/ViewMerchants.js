import React from 'react'
import imgUrl from './../../../assets/images/Logo.png'
import CIcon from '@coreui/icons-react'
import Rating from './../../../components/Rating'
import { cibFacebook, cibInstagram, cibTwitter } from '@coreui/icons'
import {
  CCard,
  CCardImage,
  CCardBody,
  CCardTitle,
  CCardText,
  CListGroup,
  CListGroupItem,
  CCardLink,
  CCol,
  CButton,
} from '@coreui/react'
const ViewMerchants = () => {
  return (
    <>
      <CCard>
        <CCol xs={12} className="merchant-profile-div">
          <CCol xs={3} className="merchant-profile-image-div">
            <CCardImage orientation="top" className="merchant-profile-image" src={imgUrl} />
          </CCol>
          <CCol xs={9}>
            <CCardBody>
              <CCardTitle className="profile-name">Addidas</CCardTitle>
              <CCardText>
                Adidas is a renowned multinational corporation that specializes in sportswear and
                footwear. Founded in 1949 by Adolf Dassler, Adidas has grown to become one of the
                world largest sportswear manufacturers. The brand is known for its iconic
                three-stripe logo, which has become synonymous with Adidas products. Adidas offers a
                wide range of products including athletic shoes, clothing, and accessories for
                various sports such as running, soccer, basketball, and more.
              </CCardText>
            </CCardBody>
            <CListGroup flush>
              <CListGroupItem className="group-item-profile-page">
                Current Promotions:<h4 className="current-promo-profile-page">02</h4>
              </CListGroupItem>
              <CListGroupItem className="group-item-profile-page">
                All Promotions:
                <h4 className="all-promo-profile-page">
                  12
                  <div className="ml-3">
                    <CButton color="primary" size="sm" id="merchant-profile-all-promotions">
                      All Promotions
                    </CButton>
                  </div>
                </h4>
              </CListGroupItem>
              <CListGroupItem className="group-item-profile-page">
                Clients:<h4 className="client-count-profile-page">20</h4>
              </CListGroupItem>
            </CListGroup>
            <CCardBody>
              <CCardLink href="#">
                <CIcon icon={cibFacebook} size="xl" />
              </CCardLink>
              <CCardLink href="#">
                <CIcon icon={cibInstagram} size="xl" />
              </CCardLink>
              <CCardLink href="#">
                <CIcon icon={cibTwitter} size="xl" />
              </CCardLink>
            </CCardBody>
          </CCol>
        </CCol>
        <CCardTitle className="raitng&reviewprofile">Rating & Review</CCardTitle>
        <CCol xs={12} className="showratingdiv">
          <CCard>
            <CCardBody>
              <CCol xs={12}>
                <h3 className="username-rating">Bhanu Rathore</h3>
                <CCol xs={3} className="ratingstarprofile">
                  <Rating />
                </CCol>
                <CCol xs={9}>
                  <CCardText className="review-profile">
                    Adidas is a renowned multinational corporation that specializes in sportswear
                    and footwear. Founded in 1949 by Adolf Dassler, Adidas has grown to become one
                    of the
                  </CCardText>
                </CCol>
              </CCol>
            </CCardBody>
          </CCard>
        </CCol>
      </CCard>
    </>
  )
}

export default ViewMerchants

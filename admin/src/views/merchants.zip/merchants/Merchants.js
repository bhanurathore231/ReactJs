import React from 'react'
import { CTable, CButton, CPagination, CPaginationItem } from '@coreui/react'
import { useNavigate } from 'react-router-dom'
const Merchants = () => {
  const navigate = useNavigate()
  const handleButtonClick = () => {
    navigate('EditMerchants')
  }
  const handleButtonViewClick = () => {
    navigate('ViewMerchants')
  }
  const columns = [
    {
      key: 'id',
      label: 'ID',
      _props: { scope: 'col' },
      selector: 'id',
      sortable: true,
    },
    {
      key: 'name',
      label: 'Name',
      _props: { scope: 'col' },
      selector: 'name',
      sortable: true,
    },
    {
      key: 'email',
      label: 'Email',
      _props: { scope: 'col' },
      selector: 'email',
      sortable: true,
    },
    {
      key: 'create_date',
      label: 'Create Date',
      _props: { scope: 'col' },
      selector: 'create_date',
      sortable: true,
    },
    {
      key: 'action',
      label: 'Action',
      _props: { scope: 'col' },
    },
  ]
  const items = [
    {
      id: 1,
      name: 'Mark',
      email: 'Otto',
      create_date: '01-01-1999',
      action: (
        <>
          <CButton
            onClick={handleButtonClick}
            color="primary"
            size="sm"
            style={{ margin: '5px 5px 5px 5px' }}
          >
            Edit
          </CButton>
          <CButton
            color="primary"
            size="sm"
            style={{ margin: '5px 5px 5px 5px' }}
            onClick={handleButtonViewClick}
          >
            View
          </CButton>
          <CButton color="primary" size="sm" style={{ margin: '5px 5px 5px 5px' }}>
            Delete
          </CButton>
        </>
      ),
      _cellProps: { id: { scope: 'row' }, action: { colSpan: 2 } },
    },
    {
      id: 2,
      name: 'Jacob',
      email: 'Thornton@gmail.com',
      create_date: '01-01-1999',
      action: (
        <>
          <CButton
            onClick={handleButtonClick}
            color="primary"
            size="sm"
            style={{ margin: '5px 5px 5px 5px' }}
          >
            Edit
          </CButton>
          <CButton
            color="primary"
            size="sm"
            style={{ margin: '5px 5px 5px 5px' }}
            onClick={handleButtonViewClick}
          >
            View
          </CButton>
          <CButton color="primary" size="sm" style={{ margin: '5px 5px 5px 5px' }}>
            Delete
          </CButton>
        </>
      ),
      _cellProps: { id: { scope: 'row' }, action: { colSpan: 2 } },
    },
    {
      id: 3,
      name: 'Larry the Bird',
      email: 'test@twitter.com',
      create_date: '01-01-1999',
      action: (
        <>
          <CButton
            onClick={handleButtonClick}
            color="primary"
            size="sm"
            style={{ margin: '5px 5px 5px 5px' }}
          >
            Edit
          </CButton>
          <CButton
            color="primary"
            size="sm"
            style={{ margin: '5px 5px 5px 5px' }}
            onClick={handleButtonViewClick}
          >
            View
          </CButton>
          <CButton color="primary" size="sm" style={{ margin: '5px 5px 5px 5px' }}>
            Delete
          </CButton>
        </>
      ),
      _cellProps: { id: { scope: 'row' }, action: { colSpan: 2 } },
    },
    {
      id: 4,
      name: 'Bhanu',
      email: 'bhanutest@twitter.com',
      create_date: '01-01-1999',
      action: (
        <>
          <CButton
            onClick={handleButtonClick}
            color="primary"
            size="sm"
            style={{ margin: '5px 5px 5px 5px' }}
          >
            Edit
          </CButton>
          <CButton
            color="primary"
            size="sm"
            style={{ margin: '5px 5px 5px 5px' }}
            onClick={handleButtonViewClick}
          >
            View
          </CButton>
          <CButton color="primary" size="sm" style={{ margin: '5px 5px 5px 5px' }}>
            Delete
          </CButton>
        </>
      ),
      _cellProps: { id: { scope: 'row' }, action: { colSpan: 2 } },
    },
    {
      id: 5,
      name: 'Narendra',
      email: 'test@yahoo.com',
      create_date: '01-01-1999',
      action: (
        <>
          <CButton
            onClick={handleButtonClick}
            color="primary"
            size="sm"
            style={{ margin: '5px 5px 5px 5px' }}
          >
            Edit
          </CButton>
          <CButton
            color="primary"
            size="sm"
            style={{ margin: '5px 5px 5px 5px' }}
            onClick={handleButtonViewClick}
          >
            View
          </CButton>
          <CButton color="primary" size="sm" style={{ margin: '5px 5px 5px 5px' }}>
            Delete
          </CButton>
        </>
      ),
      _cellProps: { id: { scope: 'row' }, action: { colSpan: 2 } },
    },
  ]
  return (
    <>
      <CTable id="merchantstable" columns={columns} items={items} />
      <CPagination aria-label="Page navigation example">
        <CPaginationItem aria-label="Previous" disabled>
          <span aria-hidden="true">&laquo;</span>
        </CPaginationItem>
        <CPaginationItem active>1</CPaginationItem>
        <CPaginationItem aria-label="Next">
          <span aria-hidden="true">&raquo;</span>
        </CPaginationItem>
      </CPagination>
    </>
  )
}

export default Merchants

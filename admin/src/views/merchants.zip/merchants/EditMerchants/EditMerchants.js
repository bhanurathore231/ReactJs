import React, { useState } from 'react'
import { CFormInput, CForm, CFormTextarea, CButton, CModal, CModalBody } from '@coreui/react'
const EditMerchants = () => {
  const [visible, setVisible] = useState(false)
  return (
    <>
      <CForm>
        <h2>Edit Mercent Detail</h2>
        <div className="mb-3">
          <CFormInput
            type="name"
            id="merchant-name"
            label="Name"
            placeholder="Enter Merchant Name"
          />
        </div>
        <div className="mb-3">
          <CFormInput
            type="email"
            id="merchant-address"
            label="Email"
            placeholder="Enter Merchant Email"
          />
        </div>
        <div className="mb-3">
          <CFormInput
            type="password"
            id="merchant-password"
            label="Password"
            placeholder="Enter Merchant Password"
          />
        </div>
        <div className="mb-3">
          <CFormInput
            type="text"
            id="merchant-website"
            label="Website"
            placeholder="Enter Merchant Link"
          />
        </div>
        <div className="mb-3">
          <CFormInput type="file" id="formFile" label="Merchant Logo" />
        </div>
        <div className="mb-3">
          <CFormInput
            type="text"
            id="merchant-address"
            label="Social links"
            placeholder="Facebook"
          />
        </div>
        <div className="mb-3">
          <CFormInput type="text" id="twitter-link-merchants" placeholder="Twitter " />
        </div>
        <div className="mb-3">
          <CFormInput type="text" id="insta-link-merchants" placeholder="Instagram" />
        </div>
        <div className="mb-3">
          <CFormTextarea
            id="bioTextarea"
            label="About"
            placeholder="Enter Detail for Mercent"
            rows={3}
          ></CFormTextarea>
        </div>
        <div className="mb-3 create-merchant">
          <CButton color="primary" onClick={() => setVisible(!visible)}>
            Save
          </CButton>
        </div>
      </CForm>
      <CModal visible={visible} onClose={() => setVisible(false)}>
        <CModalBody>Merchant Updated Sucessfully</CModalBody>
      </CModal>
    </>
  )
}

export default EditMerchants

import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import {
  CButton,
  CCard,
  CCardBody,
  CCol,
  CContainer,
  CForm,
  CFormInput,
  CInputGroup,
  CInputGroupText,
  CRow,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { cilLockLocked, cilUser, cilMobile, cilImagePlus, cilShareAlt } from '@coreui/icons'

const Register = () => {
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [email, setEmail] = useState('')
  const [phone, setPhone] = useState('')
  const [clientprofilepic, setClientprofilepic] = useState('')
  const [refferal_code, setRefferal_code] = useState('')

  const handleButtonClick = () => {
    alert(username + password + email + phone + clientprofilepic + refferal_code)
    var formdata = new FormData()
    formdata.append('username', username)
    formdata.append('password', password)
    formdata.append('email', email)
    formdata.append('phone', phone)
    formdata.append('clientprofilepic', clientprofilepic)
    formdata.append('refferal_code', refferal_code)

    var requestOptions = {
      method: 'POST',
      body: formdata,
      redirect: 'follow',
      mode: 'no-cors',
    }

    fetch('https://ryankadminapi.readyforyourreview.com/registerapi.php', requestOptions)
      .then((response) => response.text())
      .then((result) => console.log(result))
      .catch((error) => console.log('error', error))
  }
  return (
    <div className="bg-light min-vh-100 d-flex flex-row align-items-center">
      <CContainer>
        <CRow className="justify-content-center">
          <CCol md={9} lg={7} xl={6}>
            <CCard className="mx-4">
              <CCardBody className="p-4">
                <CForm>
                  <h1>Register</h1>
                  <p className="text-medium-emphasis">Create your account</p>
                  <CInputGroup className="mb-3">
                    <CInputGroupText>
                      <CIcon icon={cilUser} />
                    </CInputGroupText>
                    <CFormInput
                      name="username"
                      placeholder="Username"
                      autoComplete="username"
                      onChange={(e) => setUsername(e.target.value)}
                    />
                  </CInputGroup>
                  <CInputGroup className="mb-3">
                    <CInputGroupText>@</CInputGroupText>
                    <CFormInput
                      type="email"
                      name="email"
                      placeholder="Email"
                      autoComplete="email"
                      onChange={(e) => setEmail(e.target.value)}
                    />
                  </CInputGroup>
                  <CInputGroup className="mb-3">
                    <CInputGroupText>
                      <CIcon icon={cilMobile} />
                    </CInputGroupText>
                    <CFormInput
                      name="phone"
                      placeholder="Phone"
                      autoComplete="phone"
                      onChange={(e) => setPhone(e.target.value)}
                    />
                  </CInputGroup>
                  <CInputGroup className="mb-3">
                    <CInputGroupText>
                      <CIcon icon={cilImagePlus} />
                    </CInputGroupText>
                    <CFormInput
                      name="clientprofilepic"
                      type="file"
                      id="clientprofilepic"
                      onChange={(e) => setClientprofilepic(e.target.value)}
                    />
                  </CInputGroup>
                  <CInputGroup className="mb-3">
                    <CInputGroupText>
                      <CIcon icon={cilLockLocked} />
                    </CInputGroupText>
                    <CFormInput
                      type="password"
                      placeholder="Password"
                      autoComplete="new-password"
                      onChange={(e) => setPassword(e.target.value)}
                    />
                  </CInputGroup>
                  <CInputGroup className="mb-3">
                    <CInputGroupText>
                      <CIcon icon={cilShareAlt} />
                    </CInputGroupText>
                    <CFormInput
                      type="text"
                      name="refferal_code"
                      placeholder="Refferal Code"
                      autoComplete="Refferal Code"
                      onChange={(e) => setRefferal_code(e.target.value)}
                    />
                  </CInputGroup>
                  <div className="d-grid">
                    <Link to="/merchantspromotion">
                      <CButton color="success" onClick={handleButtonClick}>
                        Create Account
                      </CButton>
                    </Link>
                  </div>
                </CForm>
              </CCardBody>
            </CCard>
          </CCol>
        </CRow>
      </CContainer>
    </div>
  )
}

export default Register
